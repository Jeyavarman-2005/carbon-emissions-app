import React, { useState, useEffect } from 'react';
import { getBusinesses, getPlantData } from '../../services/api_op';
import { downloadAndFilterExcelBrowser } from '../../services/downloadAndFilterExcelBrowser';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';
import styles from './DashboardPage.module.css';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Line, ComposedChart, LabelList } from 'recharts';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { FiBriefcase, FiPackage, FiSettings, FiArrowRight, FiLoader, FiDownload } from 'react-icons/fi';
import { FiCalendar, FiDollarSign, FiTrendingUp, FiLock, FiUnlock, FiCheck } from 'react-icons/fi';
import supabase from '../../backend/config/supabase';
import * as XLSX from 'xlsx';

const DashboardPage = () => {
  const [businesses, setBusinesses] = useState([]);
  const [plants, setPlants] = useState([]);
  const [selectedBusiness, setSelectedBusiness] = useState('');
  const [selectedPlant, setSelectedPlant] = useState('');
  const [emissionsData, setEmissionsData] = useState(null);
  const [loading, setLoading] = useState({
    businesses: false,
    plants: false,
    emissions: false,
    projects: false,
    download: false
  });
  const [error, setError] = useState('');
  const [showPlantPrompt, setShowPlantPrompt] = useState(false);
  const [projectParams, setProjectParams] = useState({
    targetDate: new Date(),
    investment: '',
    carbonEmission: ''
  });
  const [paramsEditable, setParamsEditable] = useState(false);
  const [topProjects, setTopProjects] = useState([
    { id: 1, name: '--', reduction: '--', investment: '--', payback: '--' },
    { id: 2, name: '--', reduction: '--', investment: '--', payback: '--' },
    { id: 3, name: '--', reduction: '--', investment: '--', payback: '--' },
    { id: 4, name: '--', reduction: '--', investment: '--', payback: '--' },
    { id: 5, name: '--', reduction: '--', investment: '--', payback: '--' }
  ]);
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [allProjects, setAllProjects] = useState([]);

  // Load businesses on mount
  useEffect(() => {
    const loadBusinesses = async () => {
      try {
        setLoading(prev => ({ ...prev, businesses: true }));
        setError('');
        
        const businesses = await getBusinesses();
        
        if (!Array.isArray(businesses)) {
          throw new Error('Invalid business data format');
        }
        
        setBusinesses(businesses);
      } catch (error) {
        console.error('Load error:', error);
        setError(`Failed to load businesses. ${error.message}`);
        
        if (error.message.includes('Failed to fetch')) {
          setError('Connection failed. Please check your network and settings.');
        }
      } finally {
        setLoading(prev => ({ ...prev, businesses: false }));
      }
    };
    
    loadBusinesses();
  }, []);

  // Load plants when business is selected
  useEffect(() => {
    if (selectedBusiness) {
      const loadPlants = async () => {
        try {
          setLoading(prev => ({ ...prev, plants: true }));
          setError('');
          setSelectedPlant('');
          setEmissionsData(null);
          
          const response = await getPlantData(selectedBusiness);
          
          if (!response.plants || !Array.isArray(response.plants)) {
            throw new Error('Invalid plants data format');
          }
          
          setPlants(response.plants);
        } catch (err) {
          setError('Failed to load plants');
          console.error('Plant load error:', err);
        } finally {
          setLoading(prev => ({ ...prev, plants: false }));
        }
      };
      
      loadPlants();
    }
  }, [selectedBusiness]);

  // Load emissions and projects when plant is selected
  useEffect(() => {
    if (selectedBusiness && selectedPlant) {
      const loadPlantData = async () => {
        try {
          setLoading(prev => ({ ...prev, plants: true, emissions: true, projects: true }));
          setError('');
          
          // Load emissions data from API
          const response = await getPlantData(selectedBusiness, selectedPlant);
          if (response.emissionsData) {
            setEmissionsData(response.emissionsData);
          } else {
            // Fallback to mock data if API doesn't return emissions data
            const mockEmissionsData = {
              scope1_2026: 0,
              scope2_2026: 0,
              scope1_2027: 0,
              scope2_2027: 0,
              scope1_2028: 0,
              scope2_2028: 0,
              scope1_2029: 0,
              scope2_2029: 0,
              scope1_2030: 0,
              scope2_2030: 0,
              reductionTarget: 0,
              targetYear: 2028
            };
            setEmissionsData(mockEmissionsData);
          }
          
          // Load projects data
          const businessObj = businesses.find(b => b.id === selectedBusiness);
          const plantObj = plants.find(p => p.id === selectedPlant);
          
          if (!businessObj || !plantObj) {
            throw new Error('Could not find business or plant details');
          }
          
          const filename = `${businessObj.name}_${plantObj.name}.xlsx`;
          const { data, error } = await supabase
            .storage
            .from('project-files')
            .download(`uploads/${filename}`);
          
          if (error) throw error;
          
          const arrayBuffer = await data.arrayBuffer();
          const workbook = XLSX.read(arrayBuffer);
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const projects = XLSX.utils.sheet_to_json(worksheet);
          
          setAllProjects(projects);
          setFilteredProjects(projects);
          
          // Set initial top projects
          const initialTop5 = projects
            .sort((a, b) => b['Estimated Carbon Reduction in Kg/CO2 per annum'] - 
                            a['Estimated Carbon Reduction in Kg/CO2 per annum'])
            .slice(0, 5)
            .map((p, i) => ({
              id: i + 1,
              name: p.Project,
              reduction: (p['Estimated Carbon Reduction in Kg/CO2 per annum'] / 1000).toFixed(2),
              investment: p['Estimated Investment in Rs.'].toLocaleString(),
              payback: p['Payback period']
            }));
          
          setTopProjects(initialTop5);
          
        } catch (err) {
          console.error('Plant data load error:', err);
          setError('Failed to load plant data');
        } finally {
          setLoading(prev => ({ ...prev, plants: false, emissions: false, projects: false }));
        }
      };
      
      loadPlantData();
    }
  }, [selectedBusiness, selectedPlant]);

  const prepareChartData = () => {
    if (!emissionsData) return [];
    
    return [2026, 2027, 2028, 2029, 2030].map(year => {
      const scope1 = emissionsData[`scope1_${year}`] || 0;
      const scope2 = emissionsData[`scope2_${year}`] || 0;
      const total = scope1 + scope2;
      const reductionTarget = emissionsData.reductionTarget || 5;
      const targetValue = year === (emissionsData.targetYear || 2030) ? reductionTarget : null;
      
      return {
        year: year.toString(),
        scope1,
        scope2,
        total,
        targetValue,
        reductionTarget
      };
    });
  };

  const handleSubmitParams = async () => {
    console.log('Submit clicked - starting filter process');
    if (!selectedBusiness || !selectedPlant) {
      console.error('Business or plant not selected');
      alert('Please select both Business and Plant first');
      return;
    }

    try {
      setLoading(prev => ({ ...prev, projects: true }));
      console.log('Loading state set to true');
      
      // Calculate months difference for payback period
      const today = new Date();
      const targetDate = projectParams.targetDate;
      console.log('Today:', today, 'Target Date:', targetDate);
      
      const monthsDiff = (targetDate.getFullYear() - today.getFullYear()) * 12 + 
                        (targetDate.getMonth() - today.getMonth());
      console.log('Months difference:', monthsDiff);
      
      // Filter projects based on parameters
      let filtered = [...allProjects];
      console.log('Total projects before filtering:', filtered.length);
      
      // Always apply payback period filter if target date is set
      if (projectParams.targetDate) {
        filtered = filtered.filter(p => {
          const paybackText = p['Payback period'];
          let paybackMonths = 0;
          
          // Parse payback period
          if (paybackText.includes('<')) {
            paybackMonths = 11; // Just under 1 year
          } else {
            const paybackValue = parseFloat(paybackText);
            if (paybackText.includes('year')) {
              paybackMonths = paybackValue * 12;
            } else {
              paybackMonths = paybackValue;
            }
          }
          
          console.log(`Project: ${p.Project}, Payback: ${paybackMonths} months`);
          return paybackMonths <= monthsDiff;
        });
        console.log('Projects after payback filter:', filtered.length);
      }
      
      // Apply investment filter if provided
      if (projectParams.investment) {
        const investmentLimit = Number(projectParams.investment);
        console.log('Applying investment filter with limit:', investmentLimit);
        filtered = filtered.filter(p => p['Estimated Investment in Rs.'] <= investmentLimit);
        console.log('Projects after investment filter:', filtered.length);
      }
      
      // Apply CO2 reduction filter if provided
      if (projectParams.carbonEmission) {
        const co2Target = Number(projectParams.carbonEmission) * 1000;
        console.log('Applying CO2 filter with target:', co2Target);
        filtered = filtered.filter(p => p['Estimated Carbon Reduction in Kg/CO2 per annum'] >= co2Target);
        console.log('Projects after CO2 filter:', filtered.length);
      }
      
      // Sort by carbon reduction (descending) and take top 5
      const top5 = filtered
        .sort((a, b) => b['Estimated Carbon Reduction in Kg/CO2 per annum'] - 
                        a['Estimated Carbon Reduction in Kg/CO2 per annum'])
        .slice(0, 5)
        .map((p, i) => ({
          id: i + 1,
          name: p.Project,
          reduction: (p['Estimated Carbon Reduction in Kg/CO2 per annum'] / 1000).toFixed(2),
          investment: p['Estimated Investment in Rs.'].toLocaleString(),
          payback: p['Payback period']
        }));
      
      console.log('Top 5 projects:', top5);
      
      // Fill remaining slots with placeholders if less than 5 projects
      while (top5.length < 5) {
        top5.push({
          id: top5.length + 1,
          name: '--',
          reduction: '--',
          investment: '--',
          payback: '--'
        });
      }
      
      setTopProjects(top5);
      setFilteredProjects(filtered);
      console.log('State updated with filtered projects');
      
      if (filtered.length === 0) {
        console.warn('No projects matched the criteria');
        alert('No projects matched your criteria. Try adjusting your parameters.');
      } else {
        console.log('Filtering completed successfully');
        alert(`${filtered.length} projects matched your criteria. Showing top 5.`);
      }
    } catch (error) {
      console.error('Error filtering projects:', error);
      alert('Failed to filter projects. Check console for details.');
    } finally {
      setLoading(prev => ({ ...prev, projects: false }));
      console.log('Loading state set to false');
    }
  };

  const handleDownloadProjects = () => {
    if (filteredProjects.length === 0) {
      alert('No projects to download');
      return;
    }

    try {
      // Create CSV content
      let csvContent = "Project,Category,Approach,Estimated Carbon Reduction (tons),Estimated Investment (Rs.),Estimated Timeline,Payback Period\n";
      
      filteredProjects.forEach(project => {
        csvContent += `"${project.Project}",${project.Category},${project.Approach},${(project['Estimated Carbon Reduction in Kg/CO2 per annum'] / 1000).toFixed(2)},${project['Estimated Investment in Rs.']},${project['Estimated Timeline']},"${project['Payback period']}"\n`;
      });
      
      // Create download link
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      
      // Get business and plant names for filename
      const businessObj = businesses.find(b => b.id === selectedBusiness);
      const plantObj = plants.find(p => p.id === selectedPlant);
      const filename = `TopProjects_${businessObj?.name || 'business'}_${plantObj?.name || 'plant'}.csv`;
      
      link.setAttribute('download', filename);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error downloading projects:', error);
      alert('Failed to download projects');
    }
  };

  const handlePlantSelectClick = () => {
    if (!selectedBusiness) {
      setShowPlantPrompt(true);
    }
  };

  const handleParamChange = (e) => {
    const { name, value } = e.target;
    setProjectParams(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleDateChange = (date) => {
    setProjectParams(prev => ({
      ...prev,
      targetDate: date
    }));
  };

  const chartData = prepareChartData();

  return (
    <div className={styles.dashboardContainer}>
      <Header />
      
      {/* Business and Plant Selector with Project Parameters */}
      <div className={styles.topSection}>
        {/* Left Component - Business/Plant Selection */}
        <div className={styles.businessSelector}>
          <div className={styles.cardHeader}>
            <h3 className={styles.cardTitle}>Mention Company Details</h3>
          </div>

          <div className={styles.selectorGrid}>
            <div className={styles.inputGroup}>
              <label>
                <FiBriefcase className={styles.inputIcon} />
                Business Unit
              </label>
              <select
                value={selectedBusiness}
                onChange={(e) => setSelectedBusiness(e.target.value)}
                className={styles.modernSelect}
              >
                <option value="">Select Business</option>
                {businesses.map(business => (
                  <option key={business.id} value={business.id}>{business.name}</option>
                ))}
              </select>
            </div>

            <div className={styles.inputGroup}>
              <label>
                <FiPackage className={styles.inputIcon} />
                Production Plant
              </label>
              <select
                value={selectedPlant}
                onChange={(e) => setSelectedPlant(e.target.value)}
                className={styles.modernSelect}
                disabled={!selectedBusiness || loading.plants}
              >
                <option value="">
                  {loading.plants ? (
                    <span className={styles.loadingText}>
                      <FiLoader className={styles.spinner} /> Loading plants...
                    </span>
                  ) : selectedBusiness ? "Select Plant" : "Select Business First"}
                </option>
                {plants.map(plant => (
                  <option key={plant.id} value={plant.id}>{plant.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Right Component - Project Constraints */}
        <div className={styles.constraintsCard}>
          <div className={styles.cardHeader}>
            <h3 className={styles.cardTitle}>Project Parameters</h3>
          </div>

          <div className={styles.constraintsForm}>
            <div className={styles.formRow}>
              <div className={styles.inputGroup}>
                <label>Target Year</label>
                <DatePicker
                  selected={projectParams.targetDate}
                  onChange={handleDateChange}
                  dateFormat="MM/yyyy"
                  showMonthYearPicker
                  className={styles.yearInput}
                  placeholderText="Select month and year"
                  minDate={new Date()}
                />
              </div>
            </div>

            <div className={styles.formRow}>
              <div className={styles.inputGroup}>
                <label>Investment (₹)</label>
                <div className={styles.currencyInput}>
                  <span>₹</span>
                  <input
                    type="number"
                    name="investment"
                    value={projectParams.investment}
                    onChange={handleParamChange}
                    placeholder="0.00"
                    min="0"
                  />
                </div>
              </div>

              <div className={styles.inputGroup}>
                <label>CO₂ Emission (tons)</label>
                <input
                  type="number"
                  name="carbonEmission"
                  value={projectParams.carbonEmission}
                  onChange={handleParamChange}
                  placeholder="0.00"
                  min="0"
                  step="0.01"
                />
              </div>
            </div>

            <div className={styles.buttonGroup}>
              <button
                className={styles.saveButton}
                onClick={handleSubmitParams}
                disabled={!selectedBusiness || !selectedPlant || loading.projects}
              >
                {loading.projects ? (
                  <FiLoader className={styles.spinner} />
                ) : (
                  <>
                    SUBMIT
                    <FiArrowRight className={styles.buttonIcon} />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {loading.projects && (
        <div className={styles.loadingOverlay}>
          <FiLoader className={styles.spinner} />
          <p>Filtering projects...</p>
        </div>
      )}

      {error && (
        <div className={styles.errorBanner}>
          <p>{error}</p>
          <button onClick={() => setError('')}>Dismiss</button>
        </div>
      )}

      {/* Main Content */}
      <div className={styles.mainContent}>
        {/* Left Section - Chart */}
        <div className={styles.chartSection}>
          <div className={styles.sectionHeader}>
            <h2>EMISSIONS OVERVIEW</h2>
            <div className={styles.legend}>
              <div className={styles.legendItem}>
                <span className={styles.legendColor + ' ' + styles.scope1}></span>
                <span>Scope 1</span>
              </div>
              <div className={styles.legendItem}>
                <span className={styles.legendColor + ' ' + styles.scope2}></span>
                <span>Scope 2</span>
              </div>
              <div className={styles.legendItem}>
                <span className={styles.legendColor + ' ' + styles.target}></span>
                <span>Reduction Target</span>
              </div>
            </div>
          </div>
          
          <div className={styles.chartWrapper}>
            <ResponsiveContainer width="100%" height="90%">
              {loading.emissions ? (
                <div className={styles.chartPlaceholder}>
                  <div className={styles.placeholderContent}>
                    <FiLoader className={styles.spinner} style={{ fontSize: '2rem' }} />
                    <p>Loading emissions data...</p>
                  </div>
                </div>
              ) : emissionsData ? (
                <ComposedChart
                  data={chartData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis 
                    dataKey="year" 
                    tick={{ fill: '#6B7280' }}
                    axisLine={{ stroke: '#E5E7EB' }}
                    padding={{ left: 20, right: 20 }}
                  />
                  <YAxis 
                    label={{ 
                      value: 'Carbon Emission in Tons', 
                      angle: -90, 
                      position: 'insideLeft',
                      fill: '#6B7280',
                      fontWeight:"bold" ,
                      dy: 100
                    }}
                    tick={{ fill: '#6B7280' }}
                    axisLine={{ stroke: '#E5E7EB' }}
                  />
                  <Tooltip 
                    formatter={(value, name) => {
                      if (name === 'targetValue') return [`${value} tons`, 'Reduction Target'];
                      return [`${value} tons`, name];
                    }}
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #E5E7EB',
                      borderRadius: '6px',
                      boxShadow: '0 2px 4px rgba(0,0,0,0.05)'
                    }}
                  />
                  <Bar 
                    dataKey="scope1" 
                    name="Scope 1" 
                    stackId="a" 
                    fill="#3B82F6"
                    radius={[4, 4, 0, 0]}
                    barSize={50}
                  >
                    <LabelList 
                      dataKey="scope1" 
                      position="inside" 
                      formatter={(value) => value > 0 ? `S1` : ''}
                      fill="#fff"
                    />
                  </Bar>
                  <Bar 
                    dataKey="scope2" 
                    name="Scope 2" 
                    stackId="a" 
                    fill="#10B981"
                    radius={[4, 4, 0, 0]}
                    barSize={50}
                  >
                    <LabelList 
                      dataKey="scope2" 
                      position="inside" 
                      formatter={(value) => value > 0 ? `S2` : ''}
                      fill="#fff"
                    />
                  </Bar>
                  <Bar 
                    dataKey="total" 
                    name="Total" 
                    fill="transparent"
                  >
                    <LabelList
                      dataKey="total"
                      position="top"
                      fill="#374151"
                      content={(props) => {
                        const { x, y, value } = props;
                        return (
                          <text
                            x={x - 30}
                            y={y-5}
                            fill="#374151"
                            textAnchor="middle"
                            fontSize={16}  
                            fontWeight="bold" 
                          >
                            {`Total: ${value}`}
                          </text>
                        );
                      }}
                    />
                  </Bar>
                  <Line
                    type="monotone"
                    dataKey="targetValue"
                    stroke="#EF4444"
                    strokeWidth={2}
                    dot={{ r: 4, fill: '#EF4444' }}
                    activeDot={{ r: 6, stroke: '#EF4444', strokeWidth: 2, fill: '#fff' }}
                    name="Reduction Target"
                  />
                </ComposedChart>
              ) : (
                <div className={styles.chartPlaceholder}>
                  <div className={styles.placeholderContent}>
                    <h3>No Chart Data</h3>
                    <p>Select a business and plant to view emissions visualization</p>
                  </div>
                </div>
              )}
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Right Section - Tables */}
        <div className={styles.tablesSection}>
          {/* Emissions Table */}
          <div className={styles.tableSection}>
            <div className={styles.sectionHeader}>
              <h2>CARBON EMISSIONS</h2>
              <span className={styles.units}>tons/year</span>
            </div>
            
            <div className={styles.tableWrapper}>
              <table className={styles.emissionsTable}>
                <thead>
                  <tr>
                    <th>SCOPE</th>
                    {[2026, 2027, 2028, 2029, 2030].map(year => (
                      <th key={year}>{year}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {emissionsData ? (
                    <>
                      <tr>
                        <td>Scope 1</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`scope1-${year}`}>
                            {emissionsData[`scope1_${year}`]?.toFixed() || '0.00'}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td>Scope 2</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`scope2-${year}`}>
                            {emissionsData[`scope2_${year}`]?.toFixed(2) || '0.00'}
                          </td>
                        ))}
                      </tr>
                      <tr className={styles.totalRow}>
                        <td>TOTAL</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => {
                          const scope1 = emissionsData[`scope1_${year}`] || 0;
                          const scope2 = emissionsData[`scope2_${year}`] || 0;
                          return (
                            <td key={`total-${year}`}>
                              {(scope1 + scope2).toFixed(2)}
                            </td>
                          );
                        })}
                      </tr>
                    </>
                  ) : (
                    <>
                      <tr>
                        <td>Scope 1</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`scope1-${year}`}>--</td>
                        ))}
                      </tr>
                      <tr>
                        <td>Scope 2</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`scope2-${year}`}>--</td>
                        ))}
                      </tr>
                      <tr className={styles.totalRow}>
                        <td>TOTAL</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`total-${year}`}>--</td>
                        ))}
                      </tr>
                    </>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Top Projects Table */}
          <div className={styles.tableSection}>
            <div className={styles.sectionHeader}>
              <h2>TOP PROJECTS</h2>
              <span className={styles.units}>potential impact</span>
              <button 
                onClick={handleDownloadProjects}
                className={styles.downloadButton}
                disabled={topProjects[0].name === '--'}
              >
                <FiDownload className={styles.downloadIcon} />
                Download List
              </button>
            </div>
            
            <div className={styles.tableWrapper}>
              <table className={styles.projectsTable}>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Project Name</th>
                    <th>Reduction (tons)</th>
                    <th>Investment (₹)</th>
                    <th>Payback Period</th>
                  </tr>
                </thead>
                <tbody>
                  {topProjects.map((project) => (
                    <tr key={project.id}>
                      <td>{project.id}</td>
                      <td>{project.name}</td>
                      <td>{project.reduction}</td>
                      <td>{project.investment}</td>
                      <td>{project.payback}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default DashboardPage;