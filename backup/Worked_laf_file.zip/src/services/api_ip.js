const INPUT_API_URL = 'https://script.google.com/macros/s/AKfycbxp4Lsp7UxVv1JbLuADlPCM-wleBHsz15ta4Yj2E78jRHCV_M0tutohrbLkV-JXYHDt/exec';

export const saveData = async (formData) => {
  try {
    // Extract data from FormData
    const businessName = formData.get('businessName');
    const plantName = formData.get('plantName');

    if (!businessName || !plantName) {
      throw new Error('Business name and plant name are required');
    }

    // Prepare data for Google Sheets
    const dataForSheets = {
      businessName,
      plantName,
      // Add scope data
      ...Object.fromEntries(
        Array.from({ length: 5 }, (_, i) => 2026 + i).flatMap(year => [
          [`scope1_${year}`, formData.get(`scope1_${year}`) || 0],
          [`scope2_${year}`, formData.get(`scope2_${year}`) || 0]
        ])
      )
    };

    // Submit to Google Sheets
    const url = `${INPUT_API_URL}?t=${Date.now()}`;
    const response = await fetch(url, {
      method: 'POST',
      mode: 'no-cors',
      headers: {
        'Content-Type': 'text/plain',
      },
      body: JSON.stringify({
        endpoint: 'saveData',
        data: dataForSheets
      }),
    });

    return {
      success: true,
      message: 'Data successfully sent to Google Sheets'
    };

  } catch (error) {
    console.error('Error saving data:', error);
    return { 
      success: false, 
      error: error.message
    };
  }
};