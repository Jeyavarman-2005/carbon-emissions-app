import { uploadProjectFile } from '../backend/controllers/projectController';
import { createBusiness } from '../backend/controllers/businessController';
import { createPlant } from '../backend/controllers/plantController';
import supabase from '../backend/config/supabase';

const INPUT_API_URL = 'https://script.google.com/macros/s/AKfycbxp4Lsp7UxVv1JbLuADlPCM-wleBHsz15ta4Yj2E78jRHCV_M0tutohrbLkV-JXYHDt/exec';

export const saveData = async (formData) => {
  try {
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    if (!session) throw new Error('No active session');

    const businessName = formData.get('businessName');
    const plantName = formData.get('plantName');
    const file = formData.get('file');

    if (!businessName || !plantName) {
      throw new Error('Business name and plant name are required');
    }

    // Create DB records
    const business = await createBusiness({
      name: businessName,
      user_id: session.user.id
    });

    const plant = await createPlant({
      name: plantName,
      business_id: business.id,
      user_id: session.user.id
    });

    let uploadedFilePath = null;

    if (file) {
  // 1️⃣ Convert file to buffer
  const fileBuffer = await file.arrayBuffer();

  // 2️⃣ Create unique filename
  const timestamp = Date.now();
  const fileName = `projects_${timestamp}.xlsx`;

  // 3️⃣ Build the unique file path
  const path = `${business.id}/${plant.id}/${fileName}`;

  // 4️⃣ Upload to Supabase Storage
  const { error: uploadError } = await supabase.storage
    .from('co2-project-files')
    .upload(path, fileBuffer, {
      contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      upsert: true
    });

  if (uploadError) throw new Error('File upload failed: ' + uploadError.message);

  // 5️⃣ Save the path in your DB (example: businesses table)
  const { error: updateError } = await supabase
    .from('businesses')
    .update({ file_path: path })
    .eq('id', business.id);

  if (updateError) throw new Error('Failed to update DB with file path: ' + updateError.message);

  // 6️⃣ Store it locally for returning
  uploadedFilePath = path;
}

    // ⏬ Save this file path in your Google Sheets / DB!
    const dataForSheets = {
      businessId: business.id,
      businessName,
      plantId: plant.id,
      plantName,
      filePath: uploadedFilePath || null,  // IMPORTANT!
      ...Object.fromEntries(
        Array.from({ length: 5 }, (_, i) => 2026 + i).flatMap(year => [
          [`scope1_${year}`, formData.get(`scope1_${year}`) || 0],
          [`scope2_${year}`, formData.get(`scope2_${year}`) || 0]
        ])
      )
    };

    const url = `${INPUT_API_URL}?t=${Date.now()}`;
    await fetch(url, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'text/plain' },
      body: JSON.stringify({
        endpoint: 'saveData',
        data: dataForSheets
      }),
    });

    return {
      success: true,
      businessId: business.id,
      plantId: plant.id,
      filePath: uploadedFilePath
    };

  } catch (error) {
    console.error('Error saving data:', error);
    return { success: false, error: error.message };
  }
};

// Test function
export const testInputSystem = async () => {
  try {
    // First authenticate
    const { data: { session }, error: authError } = await supabase.auth.signInWithPassword({
      email: process.env.REACT_APP_TEST_EMAIL,
      password: process.env.REACT_APP_TEST_PASSWORD
    });

    if (authError) throw authError;

    const testFormData = new FormData();
    testFormData.append('businessName', "Test Business");
    testFormData.append('plantName', "Test Plant");
    testFormData.append('date', new Date().toISOString());
    testFormData.append('scope1_2026', "100");
    testFormData.append('scope2_2026', "50");

    const result = await saveData(testFormData);
    
    // Sign out after test
    await supabase.auth.signOut();

    return {
      success: result.success,
      message: 'Input system test completed',
      details: result
    };
  } catch (error) {
    return { 
      success: false, 
      error: error.message,
      stack: error.stack
    };
  }
};