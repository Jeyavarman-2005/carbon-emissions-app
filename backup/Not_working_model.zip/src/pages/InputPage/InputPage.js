import React, { useState } from 'react';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';
import styles from './InputPage.module.css';
import { useForm } from 'react-hook-form';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { saveData } from '../../services/api_ip';
import { useNavigate } from 'react-router-dom';
import { FiUpload, FiDownload, FiCalendar, FiDollarSign, FiTrendingUp } from 'react-icons/fi';

const InputPage = () => {
  const { register, handleSubmit, control, formState: { errors } } = useForm();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [file, setFile] = useState(null);
  const navigate = useNavigate();
  
   const onSubmit = async (data) => {
  data.date = selectedDate;
  
  try {
    const formData = new FormData();
    formData.append('businessName', data.businessName);
    formData.append('plantName', data.plantName);
    
    // Add scope data
    for (let year = 2026; year <= 2030; year++) {
      formData.append(`scope1_${year}`, data[`scope1_${year}`] || 0);
      formData.append(`scope2_${year}`, data[`scope2_${year}`] || 0);
    }
    
    // Add file if exists
    if (file) {
      formData.append('file', file);
    }

    const result = await saveData(formData);
    
    if (result.success) {
      alert('Data saved successfully!');
      if (result.filePath) {
        alert(`Excel file saved at: ${result.filePath}`);
      }
    } else {
      alert('Error saving data: ' + (result.error || 'Unknown error'));
    }
  } catch (error) {
    console.error('Submission error:', error);
    alert('Error saving data: ' + error.message);
  }
};

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };
  
  return (
    <div className={styles.dashboard}>
      <Header />
      <main className={styles.mainContent}>
        <form onSubmit={handleSubmit(onSubmit)} className={styles.form}>
          {/* Business and Plant Name */}
          <section className={styles.businessSection}>
            <div className={styles.inputCard}>
              <label className={styles.inputLabel}>
                <span className={styles.labelIcon}>🏢</span>
                Business Name
              </label>
              <input 
                {...register("businessName", { required: "Business name is required" })}
                type="text"
                placeholder="Enter business name"
                className={`${styles.inputField} ${errors.businessName ? styles.errorInput : ''}`}
              />
              {errors.businessName && <span className={styles.errorMessage}>{errors.businessName.message}</span>}
            </div>
            
            <div className={styles.inputCard}>
              <label className={styles.inputLabel}>
                <span className={styles.labelIcon}>🏭</span>
                Plant Name
              </label>
              <input 
                {...register("plantName", { required: "Plant name is required" })}
                type="text"
                placeholder="Enter plant name"
                className={`${styles.inputField} ${errors.plantName ? styles.errorInput : ''}`}
              />
              {errors.plantName && <span className={styles.errorMessage}>{errors.plantName.message}</span>}
            </div>
          </section>
          
          {/* Main Data Section - Only Emissions Table now */}
          <section className={styles.dataSection}>
            <div className={styles.emissionsCard}>
              <div className={styles.cardHeader}>
                <FiTrendingUp className={styles.cardIcon} />
                <h3>Carbon Emissions Forecast (tons/year)</h3>
              </div>
              <div className={styles.tableContainer}>
                <table className={styles.emissionsTable}>
                  <thead>
                    <tr>
                      <th>Scope</th>
                      {[2026, 2027, 2028, 2029, 2030].map(year => (
                        <th key={year}>{year}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Scope 1</td>
                      {[2026, 2027, 2028, 2029, 2030].map(year => (
                        <td key={`scope1-${year}`}>
                          <input 
                            {...register(`scope1_${year}`, { 
                              min: { value: 0, message: "Must be positive" }
                            })}
                            type="number"
                            step="0.01"
                            className={`${styles.tableInput} ${errors[`scope1_${year}`] ? styles.errorInput : ''}`}
                          />
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td>Scope 2</td>
                      {[2026, 2027, 2028, 2029, 2030].map(year => (
                        <td key={`scope2-${year}`}>
                          <input 
                            {...register(`scope2_${year}`, { 
                              min: { value: 0, message: "Must be positive" }
                            })}
                            type="number"
                            step="0.01"
                            className={`${styles.tableInput} ${errors[`scope2_${year}`] ? styles.errorInput : ''}`}
                          />
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </section>
          
          {/* File Upload and Template - Swapped positions */}
          <section className={styles.fileSection}>
            <div className={styles.templateCard}>
              <div className={styles.cardHeader}>
                <FiDownload className={styles.cardIcon} />
                <h3>Download Template</h3>
              </div>
              <div className={styles.templateContent}>
                <img 
                  src="/template.png" 
                  alt="Excel Template Preview" 
                  className={styles.templateImage}
                />
                <a 
                  href="/template.xlsx" 
                  download 
                  className={styles.downloadLink}
                >
                  <FiDownload className={styles.downloadIcon} />
                  Download Excel Template
                </a>
              </div>
            </div>
            
            <div className={styles.uploadCard}>
              <div className={styles.cardHeader}>
                <FiUpload className={styles.cardIcon} />
                <h3>Upload Project Data</h3>
              </div>
              <div className={styles.uploadBox}>
                <label className={styles.uploadLabel}>
                  <input 
                    type="file"
                    onChange={handleFileChange}
                    accept=".xlsx,.xls,.csv"
                    className={styles.fileInput}
                  />
                  <div className={styles.uploadContent}>
                    <FiUpload className={styles.uploadIcon} />
                    <p className={styles.uploadText}>Drag & drop your file here or click to browse</p>
                    <p className={styles.uploadSubtext}>Supports: .xlsx, .xls, .csv (Max 10MB)</p>
                    {file && (
                      <div className={styles.filePreview}>
                        Selected: {file.name}
                      </div>
                    )}
                  </div>
                </label>
              </div>
            </div>
          </section>
          
          <div className={styles.actionBar}>
            <button type="submit" className={styles.submitButton}>
              Save & Process Data
              <span className={styles.buttonArrow}>→</span>
            </button>
          </div>
        </form>
      </main>
      <Footer />
    </div>
  );
};

export default InputPage;