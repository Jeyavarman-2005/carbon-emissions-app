import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyBKLGNPmKmpZtXYmN-u5WDlVhxh6-l_dsE",
  authDomain: "carbonneutraldashboard.firebaseapp.com",
  projectId: "carbonneutraldashboard",
  storageBucket: "carbonneutraldashboard.firebasestorage.app",
  messagingSenderId: "1014293577691",
  appId: "1:1014293577691:web:7e44e889f1cd02ec6c71fe"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

// Initialize Cloud Storage and get a reference to the service
const storage = getStorage(app);

export { db, storage };