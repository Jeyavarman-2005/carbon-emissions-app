const DASHBOARD_API_URL = 'https://script.google.com/macros/s/AKfycby4He8uNyCaZDJPoE5AwROfOpU_HW-tIUiJhyRBlEP-wGbr93vDCAgEqA1J6nXZGucZ/exec';
const PROXY_URL = 'https://cors-anywhere.herokuapp.com/';
const USE_PROXY = process.env.NODE_ENV === 'development';

const dashboardFetch = async (endpoint, data = {}) => {
  const targetUrl = USE_PROXY ? PROXY_URL + DASHBOARD_API_URL : DASHBOARD_API_URL;
  
  try {
    const response = await fetch(targetUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest'
      },
      body: JSON.stringify({ endpoint, data }),
      redirect: 'follow'
    });

    // Handle redirects
    const finalResponse = response.redirected ? 
      await fetch(response.url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({ endpoint, data })
      }) : response;

    const result = await finalResponse.json();
    
    if (!result.success) {
      throw new Error(result.error || 'Dashboard API request failed');
    }

    return result.data;
  } catch (error) {
    console.error(`Dashboard API Error (${endpoint}):`, {
      message: error.message,
      stack: error.stack,
      endpoint,
      data
    });
    throw new Error(`Failed to fetch ${endpoint}: ${error.message}`);
  }
};

// Dashboard API functions
export const getBusinesses = () => dashboardFetch('getBusinesses');
export const getPlantData = (businessId, plantId = null) => 
  dashboardFetch('getPlantData', { businessId, plantId });

// Test function for dashboard system
export const testDashboardSystem = async () => {
  try {
    const businesses = await getBusinesses();
    const plantData = businesses.length > 0 ? 
      await getPlantData(businesses[0].id) : null;
    
    return {
      success: true,
      businessCount: businesses.length,
      samplePlantData: plantData
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
};