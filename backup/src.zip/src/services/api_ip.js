const INPUT_API_URL = 'https://script.google.com/macros/s/AKfycbxp4Lsp7UxVv1JbLuADlPCM-wleBHsz15ta4Yj2E78jRHCV_M0tutohrbLkV-JXYHDt/exec';

export const saveData = async (data) => {
  try {
    // Using no-cors mode since we don't need to read the response
    const url = `${INPUT_API_URL}?t=${Date.now()}`;
    
    const response = await fetch(url, {
      method: 'POST',
      mode: 'no-cors', // Critical for input submissions
      headers: {
        'Content-Type': 'text/plain', // GAS prefers text/plain
      },
      body: JSON.stringify({
        endpoint: 'saveData',
        data
      })
    });

    // In no-cors mode we can't read the response
    // Assume success if no network error occurred
    return { success: true };
    
  } catch (error) {
    console.error('Error saving data:', {
      message: error.message,
      stack: error.stack,
      data: data // Log the data that failed to save
    });
    throw new Error(`Failed to save data: ${error.message}`);
  }
};

// Test function for input system
export const testInputSystem = async () => {
  try {
    const testData = {
      businessName: "Test Business",
      plantName: "Test Plant",
      scope1_2026: 100,
      scope2_2026: 50,
      // Include all required fields
    };
    
    const result = await saveData(testData);
    return { 
      success: result.success,
      message: 'Input system test completed'
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
};