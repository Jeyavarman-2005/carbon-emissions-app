import React, { useState, useEffect } from 'react';
import { getBusinesses, getPlantData } from '../../services/api_op';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';
import styles from './DashboardPage.module.css';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Line, ComposedChart, LabelList } from 'recharts';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { FiBriefcase, FiPackage, FiSettings, FiArrowRight, FiLoader } from 'react-icons/fi';
import { FiCalendar, FiDollarSign, FiTrendingUp, FiLock, FiUnlock, FiCheck } from 'react-icons/fi';

const DashboardPage = () => {
  const [businesses, setBusinesses] = useState([]);
  const [plants, setPlants] = useState([]);
  const [selectedBusiness, setSelectedBusiness] = useState('');
  const [selectedPlant, setSelectedPlant] = useState('');
  const [emissionsData, setEmissionsData] = useState(null);
  const [loading, setLoading] = useState({
    businesses: false,
    plants: false,
    emissions: false
  });
  const [error, setError] = useState('');
  const [showPlantPrompt, setShowPlantPrompt] = useState(false);
  const [projectParams, setProjectParams] = useState({
    targetDate: new Date('2025-01-01'),
    investment: '',
    carbonEmission: ''
  });
  const [paramsEditable, setParamsEditable] = useState(false);
  const [topProjects, setTopProjects] = useState([
    { id: 1, name: '', reduction: 0 },
    { id: 2, name: '', reduction: 0 },
    { id: 3, name: '', reduction: 0 },
    { id: 4, name: '', reduction: 0 },
    { id: 5, name: '', reduction: 0 }
  ]);

  // Load businesses on mount
  useEffect(() => {
    const loadBusinesses = async () => {
      try {
        setLoading(prev => ({ ...prev, businesses: true }));
        setError('');
        
        const businesses = await getBusinesses();
        
        if (!Array.isArray(businesses)) {
          throw new Error('Invalid business data format');
        }
        
        setBusinesses(businesses);
      } catch (error) {
        console.error('Load error:', error);
        setError(`Failed to load businesses. ${error.message}`);
        
        if (error.message.includes('Failed to fetch')) {
          setError('Connection failed. Please check your network and settings.');
        }
      } finally {
        setLoading(prev => ({ ...prev, businesses: false }));
      }
    };
    
    loadBusinesses();
  }, []);

  // Load plants when business is selected
  useEffect(() => {
    if (selectedBusiness) {
      const loadPlants = async () => {
        try {
          setLoading(prev => ({ ...prev, plants: true }));
          setError('');
          setSelectedPlant('');
          setEmissionsData(null);
          
          const response = await getPlantData(selectedBusiness);
          
          if (!response.plants || !Array.isArray(response.plants)) {
            throw new Error('Invalid plants data format');
          }
          
          setPlants(response.plants);
        } catch (err) {
          setError('Failed to load plants');
          console.error('Plant load error:', err);
        } finally {
          setLoading(prev => ({ ...prev, plants: false }));
        }
      };
      
      loadPlants();
    }
  }, [selectedBusiness]);

  // Load emissions when plant is selected
  useEffect(() => {
    if (selectedBusiness && selectedPlant) {
      const loadEmissions = async () => {
        try {
          setLoading(prev => ({ ...prev, emissions: true }));
          setError('');
          setShowPlantPrompt(false);
          
          const response = await getPlantData(selectedBusiness, selectedPlant);
          
          if (!response.emissionsData) {
            throw new Error('No emissions data found');
          }
          
          setEmissionsData(response.emissionsData);
          setParamsEditable(true);
        } catch (err) {
          setError('Failed to load emissions data');
          console.error('Emissions load error:', err);
        } finally {
          setLoading(prev => ({ ...prev, emissions: false }));
        }
      };
      
      loadEmissions();
    }
  }, [selectedBusiness, selectedPlant]);

  const prepareChartData = () => {
    if (!emissionsData) return [];
    
    return [2026, 2027, 2028, 2029, 2030].map(year => {
      const scope1 = emissionsData[`scope1_${year}`] || 0;
      const scope2 = emissionsData[`scope2_${year}`] || 0;
      const total = scope1 + scope2;
      const reductionTarget = emissionsData.reductionTarget || 5;
      const targetValue = year === (emissionsData.targetYear || 2030) ? reductionTarget : null;
      
      return {
        year: year.toString(),
        scope1,
        scope2,
        total,
        targetValue,
        reductionTarget
      };
    });
  };

  const handlePlantSelectClick = () => {
    if (!selectedBusiness) {
      setShowPlantPrompt(true);
    }
  };

  const handleParamChange = (e) => {
    const { name, value } = e.target;
    setProjectParams(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleDateChange = (date) => {
    setProjectParams(prev => ({
      ...prev,
      targetDate: date
    }));
  };

  const handleSubmitParams = () => {
    console.log('Submitted project parameters:', projectParams);
    alert('Project parameters saved successfully!');
    setParamsEditable(false);
  };

  if (loading.businesses && businesses.length === 0) {
    return (
      <div className={styles.loadingContainer}>
        <Header />
        <div className={styles.loading}>Loading businesses...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.errorContainer}>
        <Header />
        <div className={styles.error}>{error}</div>
        <button className={styles.retryButton} onClick={() => window.location.reload()}>Retry</button>
      </div>
    );
  }

  const chartData = prepareChartData();

  return (
    <div className={styles.dashboardContainer}>
      <Header />
      
      {/* Business and Plant Selector with Project Parameters */}
      <div className={styles.topSection}>
        {/* Left Component - Business/Plant Selection */}
        <div className={styles.businessSelector}>
          <div className={styles.cardHeader}>
            <h3 className={styles.cardTitle}>Mention Company Details</h3>
          </div>

          <div className={styles.selectorGrid}>
            <div className={styles.inputGroup}>
              <label>
                <FiBriefcase className={styles.inputIcon} />
                Business Unit
              </label>
              <select
                value={selectedBusiness}
                onChange={(e) => setSelectedBusiness(e.target.value)}
                className={styles.modernSelect}
              >
                <option value="">Select Business</option>
                {businesses.map(business => (
                  <option key={business.id} value={business.id}>{business.name}</option>
                ))}
              </select>
            </div>

            <div className={styles.inputGroup}>
              <label>
                <FiPackage className={styles.inputIcon} />
                Production Plant
              </label>
              <select
                value={selectedPlant}
                onChange={(e) => setSelectedPlant(e.target.value)}
                className={styles.modernSelect}
                disabled={!selectedBusiness || loading.plants}
              >
                <option value="">
                  {loading.plants ? (
                    <span className={styles.loadingText}>
                      <FiLoader className={styles.spinner} /> Loading plants...
                    </span>
                  ) : selectedBusiness ? "Select Plant" : "Select Business First"}
                </option>
                {plants.map(plant => (
                  <option key={plant.id} value={plant.id}>{plant.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Right Component - Project Constraints */}
        <div className={styles.constraintsCard}>
          <div className={styles.cardHeader}>
            <h3 className={styles.cardTitle}>Project Parameters</h3>
          </div>

          <div className={styles.constraintsForm}>
            <div className={styles.formRow}>
              <div className={styles.inputGroup}>
                <label>Target Year</label>
                <DatePicker
                  selected={projectParams.targetDate}
                  onChange={handleDateChange}
                  dateFormat="MM/yyyy" // month and year format
                  showMonthYearPicker   // this is the key change
                  className={styles.yearInput}
                  placeholderText="Select month and year"
                />
              </div>
            </div>

            <div className={styles.formRow}>
              <div className={styles.inputGroup}>
                <label>Investment (₹)</label>
                <div className={styles.currencyInput}>
                  <span>₹</span>
                  <input
                    type="number"
                    name="investment"
                    value={projectParams.investment}
                    onChange={handleParamChange}
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div className={styles.inputGroup}>
                <label>CO₂ Emission (tons)</label>
                <input
                  type="number"
                  name="carbonEmission"
                  value={projectParams.carbonEmission}
                  onChange={handleParamChange}
                  placeholder="0.00"
                />
              </div>
            </div>

            <button
              className={styles.saveButton}
              onClick={handleSubmitParams}
              disabled={!projectParams.targetDate}
            >
              SUBMIT
              <FiArrowRight className={styles.buttonIcon} />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className={styles.mainContent}>
        {/* Left Section - Chart */}
        <div className={styles.chartSection}>
          <div className={styles.sectionHeader}>
            <h2>EMISSIONS OVERVIEW</h2>
            <div className={styles.legend}>
              <div className={styles.legendItem}>
                <span className={styles.legendColor + ' ' + styles.scope1}></span>
                <span>Scope 1</span>
              </div>
              <div className={styles.legendItem}>
                <span className={styles.legendColor + ' ' + styles.scope2}></span>
                <span>Scope 2</span>
              </div>
              <div className={styles.legendItem}>
                <span className={styles.legendColor + ' ' + styles.target}></span>
                <span>Reduction Target</span>
              </div>
            </div>
          </div>
          
          <div className={styles.chartWrapper}>
            <ResponsiveContainer width="100%" height="90%">
              {loading.emissions ? (
                <div className={styles.chartPlaceholder}>
                  <div className={styles.placeholderContent}>
                    <FiLoader className={styles.spinner} style={{ fontSize: '2rem' }} />
                    <p>Loading emissions data...</p>
                  </div>
                </div>
              ) : emissionsData ? (
                <ComposedChart
                  data={chartData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis 
                    dataKey="year" 
                    tick={{ fill: '#6B7280' }}
                    axisLine={{ stroke: '#E5E7EB' }}
                    padding={{ left: 20, right: 20 }}
                  />
                  <YAxis 
                    label={{ 
                      value: 'Carbon Emission in Tons', 
                      angle: -90, 
                      position: 'insideLeft',
                      fill: '#6B7280',
                      fontWeight:"bold" ,
                      dy: 100
                    }}
                    tick={{ fill: '#6B7280' }}
                    axisLine={{ stroke: '#E5E7EB' }}
                  />
                  <Tooltip 
                    formatter={(value, name) => {
                      if (name === 'targetValue') return [`${value} tons`, 'Reduction Target'];
                      return [`${value} tons`, name];
                    }}
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #E5E7EB',
                      borderRadius: '6px',
                      boxShadow: '0 2px 4px rgba(0,0,0,0.05)'
                    }}
                  />
                  <Bar 
                    dataKey="scope1" 
                    name="Scope 1" 
                    stackId="a" 
                    fill="#3B82F6"
                    radius={[4, 4, 0, 0]}
                    barSize={50}
                  >
                    <LabelList 
                      dataKey="scope1" 
                      position="inside" 
                      formatter={(value) => value > 0 ? `S1` : ''}
                      fill="#fff"
                    />
                  </Bar>
                  <Bar 
                    dataKey="scope2" 
                    name="Scope 2" 
                    stackId="a" 
                    fill="#10B981"
                    radius={[4, 4, 0, 0]}
                    barSize={50}
                  >
                    <LabelList 
                      dataKey="scope2" 
                      position="inside" 
                      formatter={(value) => value > 0 ? `S2` : ''}
                      fill="#fff"
                    />
                  </Bar>
                  <Bar 
                    dataKey="total" 
                    name="Total" 
                    fill="transparent"
                  >
                    <LabelList
                      dataKey="total"
                      position="top"
                      fill="#374151"
                      content={(props) => {
                        const { x, y, value } = props;
                        return (
                          <text
                            x={x - 30} // move left by 10px
                            y={y-5}
                            fill="#374151"
                            textAnchor="middle"
                            fontSize={16}  
                            fontWeight="bold" 
                          >
                            {`Total: ${value}`}
                          </text>
                        );
                      }}
                    />
                  </Bar>
                  <Line
                    type="monotone"
                    dataKey="targetValue"
                    stroke="#EF4444"
                    strokeWidth={2}
                    dot={{ r: 4, fill: '#EF4444' }}
                    activeDot={{ r: 6, stroke: '#EF4444', strokeWidth: 2, fill: '#fff' }}
                    name="Reduction Target"
                  />
                </ComposedChart>
              ) : (
                <div className={styles.chartPlaceholder}>
                  <div className={styles.placeholderContent}>
                    <h3>No Chart Data</h3>
                    <p>Select a business and plant to view emissions visualization</p>
                  </div>
                </div>
              )}
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Right Section - Tables */}
        <div className={styles.tablesSection}>
          {/* Emissions Table */}
          <div className={styles.tableSection}>
            <div className={styles.sectionHeader}>
              <h2>CARBON EMISSIONS</h2>
              <span className={styles.units}>tons/year</span>
            </div>
            
            <div className={styles.tableWrapper}>
              <table className={styles.emissionsTable}>
                <thead>
                  <tr>
                    <th>SCOPE</th>
                    {[2026, 2027, 2028, 2029, 2030].map(year => (
                      <th key={year}>{year}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {emissionsData ? (
                    <>
                      <tr>
                        <td>Scope 1</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`scope1-${year}`}>
                            {emissionsData[`scope1_${year}`]?.toFixed() || '0.00'}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td>Scope 2</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`scope2-${year}`}>
                            {emissionsData[`scope2_${year}`]?.toFixed(2) || '0.00'}
                          </td>
                        ))}
                      </tr>
                      <tr className={styles.totalRow}>
                        <td>TOTAL</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => {
                          const scope1 = emissionsData[`scope1_${year}`] || 0;
                          const scope2 = emissionsData[`scope2_${year}`] || 0;
                          return (
                            <td key={`total-${year}`}>
                              {(scope1 + scope2).toFixed(2)}
                            </td>
                          );
                        })}
                      </tr>
                    </>
                  ) : (
                    <>
                      <tr>
                        <td>Scope 1</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`scope1-${year}`}>--</td>
                        ))}
                      </tr>
                      <tr>
                        <td>Scope 2</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`scope2-${year}`}>--</td>
                        ))}
                      </tr>
                      <tr className={styles.totalRow}>
                        <td>TOTAL</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`total-${year}`}>--</td>
                        ))}
                      </tr>
                    </>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Top Projects Table */}
          <div className={styles.tableSection}>
            <div className={styles.sectionHeader}>
              <h2>TOP PROJECTS</h2>
              <span className={styles.units}>potential impact</span>
            </div>
            
            <div className={styles.tableWrapper}>
              <table className={styles.projectsTable}>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Project Name</th>
                    <th>Reduction (tons)</th>
                  </tr>
                </thead>
                <tbody>
                  {topProjects.map((project, index) => (
                    <tr key={project.id}>
                      <td>{index + 1}</td>
                      <td>{project.name || '--'}</td>
                      <td>{project.reduction || '--'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default DashboardPage;