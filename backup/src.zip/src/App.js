import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import InputPage from './pages/InputPage/InputPage';
import DashboardPage from './pages/DashboardPage/DashboardPage';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/input" element={<InputPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/" element={<Navigate to="/input" replace />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;