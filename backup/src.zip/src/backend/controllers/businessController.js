import supabase from '../config/supabase';

export const createBusiness = async (name) => {
  const { data, error } = await supabase
    .from('businesses')
    .insert([{ name }])
    .select();

  if (error) throw error;
  return data[0];
};