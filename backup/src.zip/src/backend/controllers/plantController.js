import supabase from '../config/supabase';

export const createPlant = async (businessId, name) => {
  const { data, error } = await supabase
    .from('plants')
    .insert([{ business_id: businessId, name }])
    .select();

  if (error) throw error;
  return data[0];
};