import { uploadProjectFile } from '../backend/controllers/projectController';
import { createBusiness } from '../backend/controllers/businessController';
import { createPlant } from '../backend/controllers/plantController';
import supabase from '../backend/config/supabase';

const INPUT_API_URL = 'https://script.google.com/macros/s/AKfycbxp4Lsp7UxVv1JbLuADlPCM-wleBHsz15ta4Yj2E78jRHCV_M0tutohrbLkV-JXYHDt/exec';

export const saveData = async (formData) => {
  try {
    // 1️⃣ Get current session or authenticate
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    
    if (!session) {
      throw new Error('No active session. Please login first.');
    }

    // 2️⃣ Extract data from FormData
    const businessName = formData.get('businessName');
    const plantName = formData.get('plantName');
    const file = formData.get('file');

    if (!businessName || !plantName) {
      throw new Error('Business name and plant name are required');
    }

    // 3️⃣ Create business and plant in database
    const business = await createBusiness({
      name: businessName,
      user_id: session.user.id
    });

    const plant = await createPlant({
      name: plantName,
      business_id: business.id,
      user_id: session.user.id
    });

    // 4️⃣ Handle file upload if exists
    let filePath = null;
    if (file) {
      // Convert file to ArrayBuffer
      const fileBuffer = await file.arrayBuffer();
      
      // Generate unique filename
      const timestamp = new Date().getTime();
      const fileName = `projects_${timestamp}.xlsx`;
      filePath = `${session.user.id}/${business.id}/${plant.id}/${fileName}`;

      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from('co2-project-files')
        .upload(filePath, fileBuffer, {
          contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          upsert: true
        });

      if (uploadError) {
        console.error('File upload error:', uploadError);
        throw new Error('Failed to upload project file');
      }
    }

     // 5️⃣ Prepare data for Google Sheets
    const dataForSheets = {
      businessId: business.id,
      businessName,
      plantId: plant.id,
      plantName,
      // Add scope data
      ...Object.fromEntries(
        Array.from({ length: 5 }, (_, i) => 2026 + i).flatMap(year => [
          [`scope1_${year}`, formData.get(`scope1_${year}`) || 0],
          [`scope2_${year}`, formData.get(`scope2_${year}`) || 0]
        ])
      )
    };

    // 6️⃣ Submit to Google Sheets
    const url = `${INPUT_API_URL}?t=${Date.now()}`;
    await fetch(url, {
      method: 'POST',
      mode: 'no-cors',
      headers: {
        'Content-Type': 'text/plain',
      },
      body: JSON.stringify({
        endpoint: 'saveData',
        data: dataForSheets
      }),
    });

    return {
      success: true,
      businessId: business.id,
      plantId: plant.id,
      filePath: filePath
    };

  } catch (error) {
    console.error('Error saving data:', {
      message: error.message,
      stack: error.stack,
      time: new Date().toISOString()
    });
    return { 
      success: false, 
      error: error.message,
      details: error.response?.data || null
    };
  }
};

// Test function
export const testInputSystem = async () => {
  try {
    // First authenticate
    const { data: { session }, error: authError } = await supabase.auth.signInWithPassword({
      email: process.env.REACT_APP_TEST_EMAIL,
      password: process.env.REACT_APP_TEST_PASSWORD
    });

    if (authError) throw authError;

    const testFormData = new FormData();
    testFormData.append('businessName', "Test Business");
    testFormData.append('plantName', "Test Plant");
    testFormData.append('date', new Date().toISOString());
    testFormData.append('scope1_2026', "100");
    testFormData.append('scope2_2026', "50");

    const result = await saveData(testFormData);
    
    // Sign out after test
    await supabase.auth.signOut();

    return {
      success: result.success,
      message: 'Input system test completed',
      details: result
    };
  } catch (error) {
    return { 
      success: false, 
      error: error.message,
      stack: error.stack
    };
  }
};