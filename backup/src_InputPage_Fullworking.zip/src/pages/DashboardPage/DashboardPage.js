import React, { useState, useEffect } from 'react';
import { getBusinesses, getPlantData } from '../../services/api_op';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';
import styles from './DashboardPage.module.css';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Line, ComposedChart, LabelList } from 'recharts';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { FiBriefcase, FiPackage, FiSettings, FiArrowRight, FiLoader } from 'react-icons/fi';
import { FiCalendar, FiDollarSign, FiTrendingUp, FiLock, FiUnlock, FiCheck } from 'react-icons/fi';

const DashboardPage = () => {
  const [businesses, setBusinesses] = useState([]);
  const [plants, setPlants] = useState([]);
  const [selectedBusiness, setSelectedBusiness] = useState('');
  const [selectedPlant, setSelectedPlant] = useState('');
  const [emissionsData, setEmissionsData] = useState(null);
  const [loading, setLoading] = useState({
    businesses: false,
    plants: false,
    emissions: false,
    projects: false
  });
  const [error, setError] = useState('');
  const [showPlantPrompt, setShowPlantPrompt] = useState(false);
  const [projectParams, setProjectParams] = useState({
    targetDate: new Date('2025-01-01'),
    investment: '',
    carbonEmission: ''
  });
  const [paramsEditable, setParamsEditable] = useState(false);
  const [topProjects, setTopProjects] = useState([
    { id: 1, name: '--', reduction: '--' },
    { id: 2, name: '--', reduction: '--' },
    { id: 3, name: '--', reduction: '--' },
    { id: 4, name: '--', reduction: '--' },
    { id: 5, name: '--', reduction: '--' }
  ]);
  const [filteredProjects, setFilteredProjects] = useState([]);

  // Load businesses on mount
  useEffect(() => {
    const loadBusinesses = async () => {
      try {
        setLoading(prev => ({ ...prev, businesses: true }));
        setError('');
        
        const businesses = await getBusinesses();
        
        if (!Array.isArray(businesses)) {
          throw new Error('Invalid business data format');
        }
        
        setBusinesses(businesses);
      } catch (error) {
        console.error('Load error:', error);
        setError(`Failed to load businesses. ${error.message}`);
        
        if (error.message.includes('Failed to fetch')) {
          setError('Connection failed. Please check your network and settings.');
        }
      } finally {
        setLoading(prev => ({ ...prev, businesses: false }));
      }
    };
    
    loadBusinesses();
  }, []);

  // Load plants when business is selected
  useEffect(() => {
    if (selectedBusiness) {
      const loadPlants = async () => {
        try {
          setLoading(prev => ({ ...prev, plants: true }));
          setError('');
          setSelectedPlant('');
          setEmissionsData(null);
          
          const response = await getPlantData(selectedBusiness);
          
          if (!response.plants || !Array.isArray(response.plants)) {
            throw new Error('Invalid plants data format');
          }
          
          setPlants(response.plants);
        } catch (err) {
          setError('Failed to load plants');
          console.error('Plant load error:', err);
        } finally {
          setLoading(prev => ({ ...prev, plants: false }));
        }
      };
      
      loadPlants();
    }
  }, [selectedBusiness]);

  // Load emissions and projects when plant is selected
  useEffect(() => {
    if (selectedBusiness && selectedPlant) {
      const loadEmissionsAndProjects = async () => {
        try {
          setLoading(prev => ({ ...prev, emissions: true, projects: true }));
          setError('');
          setShowPlantPrompt(false);
          
          const response = await getPlantData(selectedBusiness, selectedPlant);
          
          if (!response.emissionsData) {
            throw new Error('No emissions data found');
          }
          
          setEmissionsData(response.emissionsData);
          setParamsEditable(true);
          
          // Initial load of all projects
          if (response.projects) {
            const initialTop5 = response.projects
              .sort((a, b) => b['Estimated Carbon Reduction in Kg/CO2 per annum'] - 
                              a['Estimated Carbon Reduction in Kg/CO2 per annum'])
              .slice(0, 5)
              .map((p, i) => ({
                id: i + 1,
                name: p.Project,
                reduction: (p['Estimated Carbon Reduction in Kg/CO2 per annum'] / 1000).toFixed(2)
              }));
            
            setTopProjects(initialTop5);
            setFilteredProjects(response.projects);
          }
        } catch (err) {
          setError('Failed to load data');
          console.error('Load error:', err);
        } finally {
          setLoading(prev => ({ ...prev, emissions: false, projects: false }));
        }
      };
      
      loadEmissionsAndProjects();
    }
  }, [selectedBusiness, selectedPlant]);

  // Filter projects when parameters change
  useEffect(() => {
    if (selectedBusiness && selectedPlant && filteredProjects.length > 0 && !paramsEditable) {
      const filterProjects = () => {
        try {
          setLoading(prev => ({ ...prev, projects: true }));
          
          // Calculate months difference for payback period
          const today = new Date();
          const targetDate = projectParams.targetDate;
          const monthsDiff = (targetDate.getFullYear() - today.getFullYear()) * 12 + 
                            (targetDate.getMonth() - today.getMonth());
          
          // Apply filters
          const filtered = filteredProjects.filter(p => {
            const paybackYears = parseFloat(p['Payback period'].split(' ')[0]);
            const paybackMonths = paybackYears * 12;
            
            const meetsPayback = paybackMonths <= monthsDiff;
            const meetsInvestment = !projectParams.investment || 
                                  p['Estimated Investment in Rs.'] <= Number(projectParams.investment);
            const meetsCo2Target = !projectParams.carbonEmission || 
                                 (p['Estimated Carbon Reduction in Kg/CO2 per annum'] / 1000) >= Number(projectParams.carbonEmission);
            
            return meetsPayback && meetsInvestment && meetsCo2Target;
          });
          
          // Update top 5 projects
          const top5 = filtered
            .sort((a, b) => b['Estimated Carbon Reduction in Kg/CO2 per annum'] - 
                            a['Estimated Carbon Reduction in Kg/CO2 per annum'])
            .slice(0, 5)
            .map((p, i) => ({
              id: i + 1,
              name: p.Project,
              reduction: (p['Estimated Carbon Reduction in Kg/CO2 per annum'] / 1000).toFixed(2)
            }));
          
          setTopProjects(top5);
        } catch (error) {
          console.error('Error filtering projects:', error);
        } finally {
          setLoading(prev => ({ ...prev, projects: false }));
        }
      };
      
      filterProjects();
    }
  }, [projectParams, filteredProjects, selectedBusiness, selectedPlant, paramsEditable]);

  const prepareChartData = () => {
    if (!emissionsData) return [];
    
    return [2026, 2027, 2028, 2029, 2030].map(year => {
      const scope1 = emissionsData[`scope1_${year}`] || 0;
      const scope2 = emissionsData[`scope2_${year}`] || 0;
      const total = scope1 + scope2;
      const reductionTarget = emissionsData.reductionTarget || 5;
      const targetValue = year === (emissionsData.targetYear || 2030) ? reductionTarget : null;
      
      return {
        year: year.toString(),
        scope1,
        scope2,
        total,
        targetValue,
        reductionTarget
      };
    });
  };

  const handlePlantSelectClick = () => {
    if (!selectedBusiness) {
      setShowPlantPrompt(true);
    }
  };

  const handleParamChange = (e) => {
    const { name, value } = e.target;
    setProjectParams(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleDateChange = (date) => {
    setProjectParams(prev => ({
      ...prev,
      targetDate: date
    }));
  };

  const handleSubmitParams = () => {
    console.log('Submitted project parameters:', projectParams);
    alert('Project parameters saved successfully!');
    setParamsEditable(false);
  };

  const handleDownloadProjects = async () => {
    try {
      // Create CSV content
      let csvContent = "Project,Estimated Investment (Rs.),CO2 Reduction (tons),Payback Period\n";
      
      topProjects.forEach(project => {
        if (project.name !== '--') {
          const originalProject = filteredProjects.find(p => p.Project === project.name);
          if (originalProject) {
            csvContent += `${originalProject.Project},${originalProject['Estimated Investment in Rs.']},${(originalProject['Estimated Carbon Reduction in Kg/CO2 per annum'] / 1000).toFixed(2)},${originalProject['Payback period']}\n`;
          }
        }
      });
      
      // Create download link
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `top_projects_${selectedBusiness}_${selectedPlant}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error downloading projects:', error);
      alert('Failed to download projects');
    }
  };

  if (loading.businesses && businesses.length === 0) {
    return (
      <div className={styles.loadingContainer}>
        <Header />
        <div className={styles.loading}>Loading businesses...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.errorContainer}>
        <Header />
        <div className={styles.error}>{error}</div>
        <button className={styles.retryButton} onClick={() => window.location.reload()}>Retry</button>
      </div>
    );
  }

  const chartData = prepareChartData();

  return (
    <div className={styles.dashboardContainer}>
      <Header />
      
      {/* Business and Plant Selector with Project Parameters */}
      <div className={styles.topSection}>
        {/* Left Component - Business/Plant Selection */}
        <div className={styles.businessSelector}>
          <div className={styles.cardHeader}>
            <h3 className={styles.cardTitle}>Mention Company Details</h3>
          </div>

          <div className={styles.selectorGrid}>
            <div className={styles.inputGroup}>
              <label>
                <FiBriefcase className={styles.inputIcon} />
                Business Unit
              </label>
              <select
                value={selectedBusiness}
                onChange={(e) => setSelectedBusiness(e.target.value)}
                className={styles.modernSelect}
              >
                <option value="">Select Business</option>
                {businesses.map(business => (
                  <option key={business.id} value={business.id}>{business.name}</option>
                ))}
              </select>
            </div>

            <div className={styles.inputGroup}>
              <label>
                <FiPackage className={styles.inputIcon} />
                Production Plant
              </label>
              <select
                value={selectedPlant}
                onChange={(e) => setSelectedPlant(e.target.value)}
                className={styles.modernSelect}
                disabled={!selectedBusiness || loading.plants}
              >
                <option value="">
                  {loading.plants ? (
                    <span className={styles.loadingText}>
                      <FiLoader className={styles.spinner} /> Loading plants...
                    </span>
                  ) : selectedBusiness ? "Select Plant" : "Select Business First"}
                </option>
                {plants.map(plant => (
                  <option key={plant.id} value={plant.id}>{plant.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Right Component - Project Constraints */}
        <div className={styles.constraintsCard}>
          <div className={styles.cardHeader}>
            <h3 className={styles.cardTitle}>Project Parameters</h3>
          </div>

          <div className={styles.constraintsForm}>
            <div className={styles.formRow}>
              <div className={styles.inputGroup}>
                <label>Target Year</label>
                <DatePicker
                  selected={projectParams.targetDate}
                  onChange={handleDateChange}
                  dateFormat="MM/yyyy"
                  showMonthYearPicker
                  className={styles.yearInput}
                  placeholderText="Select month and year"
                />
              </div>
            </div>

            <div className={styles.formRow}>
              <div className={styles.inputGroup}>
                <label>Investment (₹)</label>
                <div className={styles.currencyInput}>
                  <span>₹</span>
                  <input
                    type="number"
                    name="investment"
                    value={projectParams.investment}
                    onChange={handleParamChange}
                    placeholder="0.00"
                    min="0"
                  />
                </div>
              </div>

              <div className={styles.inputGroup}>
                <label>CO₂ Emission (tons)</label>
                <input
                  type="number"
                  name="carbonEmission"
                  value={projectParams.carbonEmission}
                  onChange={handleParamChange}
                  placeholder="0.00"
                  min="0"
                  step="0.01"
                />
              </div>
            </div>

            <button
              className={styles.saveButton}
              onClick={handleSubmitParams}
              disabled={!projectParams.targetDate || loading.projects}
            >
              {loading.projects ? (
                <FiLoader className={styles.spinner} />
              ) : (
                <>
                  SUBMIT
                  <FiArrowRight className={styles.buttonIcon} />
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className={styles.mainContent}>
        {/* Left Section - Chart */}
        <div className={styles.chartSection}>
          <div className={styles.sectionHeader}>
            <h2>EMISSIONS OVERVIEW</h2>
            <div className={styles.legend}>
              <div className={styles.legendItem}>
                <span className={styles.legendColor + ' ' + styles.scope1}></span>
                <span>Scope 1</span>
              </div>
              <div className={styles.legendItem}>
                <span className={styles.legendColor + ' ' + styles.scope2}></span>
                <span>Scope 2</span>
              </div>
              <div className={styles.legendItem}>
                <span className={styles.legendColor + ' ' + styles.target}></span>
                <span>Reduction Target</span>
              </div>
            </div>
          </div>
          
          <div className={styles.chartWrapper}>
            <ResponsiveContainer width="100%" height="90%">
              {loading.emissions ? (
                <div className={styles.chartPlaceholder}>
                  <div className={styles.placeholderContent}>
                    <FiLoader className={styles.spinner} style={{ fontSize: '2rem' }} />
                    <p>Loading emissions data...</p>
                  </div>
                </div>
              ) : emissionsData ? (
                <ComposedChart
                  data={chartData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis 
                    dataKey="year" 
                    tick={{ fill: '#6B7280' }}
                    axisLine={{ stroke: '#E5E7EB' }}
                    padding={{ left: 20, right: 20 }}
                  />
                  <YAxis 
                    label={{ 
                      value: 'Carbon Emission in Tons', 
                      angle: -90, 
                      position: 'insideLeft',
                      fill: '#6B7280',
                      fontWeight:"bold" ,
                      dy: 100
                    }}
                    tick={{ fill: '#6B7280' }}
                    axisLine={{ stroke: '#E5E7EB' }}
                  />
                  <Tooltip 
                    formatter={(value, name) => {
                      if (name === 'targetValue') return [`${value} tons`, 'Reduction Target'];
                      return [`${value} tons`, name];
                    }}
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #E5E7EB',
                      borderRadius: '6px',
                      boxShadow: '0 2px 4px rgba(0,0,0,0.05)'
                    }}
                  />
                  <Bar 
                    dataKey="scope1" 
                    name="Scope 1" 
                    stackId="a" 
                    fill="#3B82F6"
                    radius={[4, 4, 0, 0]}
                    barSize={50}
                  >
                    <LabelList 
                      dataKey="scope1" 
                      position="inside" 
                      formatter={(value) => value > 0 ? `S1` : ''}
                      fill="#fff"
                    />
                  </Bar>
                  <Bar 
                    dataKey="scope2" 
                    name="Scope 2" 
                    stackId="a" 
                    fill="#10B981"
                    radius={[4, 4, 0, 0]}
                    barSize={50}
                  >
                    <LabelList 
                      dataKey="scope2" 
                      position="inside" 
                      formatter={(value) => value > 0 ? `S2` : ''}
                      fill="#fff"
                    />
                  </Bar>
                  <Bar 
                    dataKey="total" 
                    name="Total" 
                    fill="transparent"
                  >
                    <LabelList
                      dataKey="total"
                      position="top"
                      fill="#374151"
                      content={(props) => {
                        const { x, y, value } = props;
                        return (
                          <text
                            x={x - 30}
                            y={y-5}
                            fill="#374151"
                            textAnchor="middle"
                            fontSize={16}  
                            fontWeight="bold" 
                          >
                            {`Total: ${value}`}
                          </text>
                        );
                      }}
                    />
                  </Bar>
                  <Line
                    type="monotone"
                    dataKey="targetValue"
                    stroke="#EF4444"
                    strokeWidth={2}
                    dot={{ r: 4, fill: '#EF4444' }}
                    activeDot={{ r: 6, stroke: '#EF4444', strokeWidth: 2, fill: '#fff' }}
                    name="Reduction Target"
                  />
                </ComposedChart>
              ) : (
                <div className={styles.chartPlaceholder}>
                  <div className={styles.placeholderContent}>
                    <h3>No Chart Data</h3>
                    <p>Select a business and plant to view emissions visualization</p>
                  </div>
                </div>
              )}
            </ResponsiveContainer>
          </div>
        </div>
        
        {/* Right Section - Tables */}
        <div className={styles.tablesSection}>
          {/* Emissions Table */}
          <div className={styles.tableSection}>
            <div className={styles.sectionHeader}>
              <h2>CARBON EMISSIONS</h2>
              <span className={styles.units}>tons/year</span>
            </div>
            
            <div className={styles.tableWrapper}>
              <table className={styles.emissionsTable}>
                <thead>
                  <tr>
                    <th>SCOPE</th>
                    {[2026, 2027, 2028, 2029, 2030].map(year => (
                      <th key={year}>{year}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {emissionsData ? (
                    <>
                      <tr>
                        <td>Scope 1</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`scope1-${year}`}>
                            {emissionsData[`scope1_${year}`]?.toFixed() || '0.00'}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td>Scope 2</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`scope2-${year}`}>
                            {emissionsData[`scope2_${year}`]?.toFixed(2) || '0.00'}
                          </td>
                        ))}
                      </tr>
                      <tr className={styles.totalRow}>
                        <td>TOTAL</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => {
                          const scope1 = emissionsData[`scope1_${year}`] || 0;
                          const scope2 = emissionsData[`scope2_${year}`] || 0;
                          return (
                            <td key={`total-${year}`}>
                              {(scope1 + scope2).toFixed(2)}
                            </td>
                          );
                        })}
                      </tr>
                    </>
                  ) : (
                    <>
                      <tr>
                        <td>Scope 1</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`scope1-${year}`}>--</td>
                        ))}
                      </tr>
                      <tr>
                        <td>Scope 2</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`scope2-${year}`}>--</td>
                        ))}
                      </tr>
                      <tr className={styles.totalRow}>
                        <td>TOTAL</td>
                        {[2026, 2027, 2028, 2029, 2030].map(year => (
                          <td key={`total-${year}`}>--</td>
                        ))}
                      </tr>
                    </>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Top Projects Table */}
          <div className={styles.tableSection}>
            <div className={styles.sectionHeader}>
              <h2>TOP PROJECTS</h2>
              <span className={styles.units}>potential impact</span>
              <button 
                onClick={handleDownloadProjects}
                className={styles.downloadButton}
                disabled={topProjects[0].name === '--'}
              >
                Download List
              </button>
            </div>
            
            <div className={styles.tableWrapper}>
              <table className={styles.projectsTable}>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Project Name</th>
                    <th>Reduction (tons)</th>
                    <th>Investment (₹)</th>
                    <th>Payback Period</th>
                  </tr>
                </thead>
                <tbody>
                  {topProjects.map((project, index) => {
                    const fullProject = filteredProjects.find(p => p.Project === project.name);
                    return (
                      <tr key={project.id}>
                        <td>{index + 1}</td>
                        <td>{project.name}</td>
                        <td>{project.reduction}</td>
                        <td>
                          {fullProject ? fullProject['Estimated Investment in Rs.'].toLocaleString() : '--'}
                        </td>
                        <td>
                          {fullProject ? fullProject['Payback period'] : '--'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default DashboardPage;

