import express from 'express';
import {
  createBusiness,
  createPlant,
  uploadProjectFile,
  getFilteredProjects,
} from '../controllers';

const router = express.Router();

// Business routes
router.post('/businesses', async (req, res) => {
  try {
    const business = await createBusiness(req.body.name);
    res.json(business);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Plant routes
router.post('/plants', async (req, res) => {
  try {
    const plant = await createPlant(req.body.businessId, req.body.name);
    res.json(plant);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Project file upload
router.post('/projects/upload', async (req, res) => {
  try {
    const { businessId, plantId, fileBuffer } = req.body;
    const result = await uploadProjectFile(businessId, plantId, fileBuffer);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Filter projects
router.get('/projects/filter', async (req, res) => {
  try {
    const { businessId, plantId, ...filters } = req.query;
    const projects = await getFilteredProjects(businessId, plantId, {
      paybackMonths: Number(filters.paybackMonths),
      investmentLimit: Number(filters.investmentLimit),
      co2Target: Number(filters.co2Target),
    });
    res.json(projects);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;